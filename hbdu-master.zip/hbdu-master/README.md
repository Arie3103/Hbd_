
## Installation

- `Fork this code`
- `Edit ucapan, panggilan in src/App.js`
- `Deploy in heroku, netlify dll`

### Demo
http://hbdu.iniherly.xyz
